const express = require('express');
const app = express();
const { auth, requiredScopes } = require('express-oauth2-jwt-bearer');
const cors = require('cors');
const ejs = require('ejs');
var bodyParser = require('body-parser')
require('dotenv').config();
const port = parseInt(process.env.PORT, 10);
// const port = 8002;
const { decode, verify, sign } = require("jws");
const secret = process.env.SESSION_TOKEN_SECRET;

var redirect_uri_final = "";
var state_final = "";
var decoded_final = "";
if (!process.env.ISSUER_BASE_URL || !process.env.AUDIENCE) {
  throw 'Make sure you have ISSUER_BASE_URL, and AUDIENCE in your .env file';
}

const corsOptions =  {
  origin: 'http://localhost:3000'
};

app.use(cors(corsOptions));

const checkJwt = auth();

app.get('/api/public', function(req, res) {
  res.json({
    message: 'Hello from a public endpoint! You don\'t need to be authenticated to see this.'
  });
});

app.get('/api/private', checkJwt, function(req, res) {
  res.json({
    message: 'Hello from a private endpoint! You need to be authenticated to see this.'
  });
});

app.get('/api/private-scoped', checkJwt, requiredScopes('read:messages'), function(req, res) {
  res.json({
    message: 'Hello from a private endpoint! You need to be authenticated and have a scope of read:messages to see this.'
  });
});

app.use(function(err, req, res, next){
  console.error(err.stack);
  return res.set(err.headers).status(err.status).json({ message: err.message });
});

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
});
// ------------------------





app.get('/', (req, res) => {
  const redirect_uri = req.query.redirect_uri;
  const state = req.query.state;
  const session_token = req.query.session_token;

  redirect_uri_final = redirect_uri;
  state_final = state;
  session_token_final = session_token

  console.log("incoming: ", session_token)

  const decoded = decode(session_token)
  decoded_final = decoded
  const verified = verify(session_token, 'HS256', secret);

  if(!verified) throw new Error("Incoming session token cannot be verified.")

  console.log("DECODED:");
  console.dir(decoded);
  console.log("ACTION VALUE");
  console.log(req.originalUrl);
  console.log(`ACTION VALUE - ${req.originalUrl.split('?')[0]}?state=${state}&session_token=${session_token}&redirect_uri=${redirect_uri}`);

  const issuedAt = Math.floor(Date.now() / 1000);

    // http://localhost:8002/api/site
  const data = { 
    subject: decoded.payload.subject,
    fields: {},
    // action: `${redirect_uri}?state=${state}&session_token=${responseToken}`
    action: `${req.originalUrl.split('?')[0]}?state=${state}&session_token=${session_token}&redirect_uri=${redirect_uri}`
  };

  const requiredFields = decoded.payload.data.requiredFields;
  requiredFieldsG = requiredFields;
  requiredFields.forEach((field) => {
    data.fields[field] = {};
  });
const html = renderProfileView(data);
  res.set('Content-Type', 'text/html');
  res.status(200).send(html);

  // res.redirect(`${redirect_uri}?state=${state}&session_token=${responseToken}`);
});





const parseBody = bodyParser.urlencoded({ extended: false });
app.post('/', parseBody, (req, res) => {
  // render form that auth-posts back to Auth0 with collected data
  const formData = req.body;
  const redirect_uri = req.query.redirect_uri;
  const state = req.query.state;
  const session_token = req.query.session_token;
    console.log("incoming: ", session_token)

  const decoded = decode(session_token)
  decoded_final = decoded
  const verified = verify(session_token, 'HS256', secret);

  if(!verified) throw new Error("Incoming session token cannot be verified.")

  console.log("DECODED:")
  console.dir(decoded)

  const issuedAt = Math.floor(Date.now() / 1000);
  const payload =  {
    ...decoded_final.payload,
    state,
    iat: issuedAt,
    exp: issuedAt + (60 * 5), // five minutes
    other: {
      profile_data_added_at: new Date().toISOString(),
      formData: formData
    }
  }

  const responseToken = sign({
    header: {
      alg: 'HS256',
      typ: 'JWT',
    },
    encoding: 'utf-8',
    payload,
    secret,
  });

  console.log("response: ", responseToken)
  
  const HTML = renderReturnView({
    action: `${redirect_uri}?state=${state}&session_token=${responseToken}`,
    formData
  });

  res.set('Content-Type', 'text/html');
  res.status(200).send(HTML);
});


function renderProfileView(data) {
  const template = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>User Profile</title>
      <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
      <style>
        h1 {
            color: green;
        }
          
        input[type=checkbox] {
            vertical-align: middle;
            position: relative;
            bottom: 1px;
            width: auto;
        }
          
        label {
            display: block;
        }
    </style>
    </head>
    <body>
      <div class="jumbotron">
        <div class="container">
          <div class="row" style="padding-top: 20px;">
            <div class="col-md-6 col-sm-offset-2">
              <p class="lead">Hello <strong><%= subject %></strong>, we just need a couple more things from you to complete your profile:</p>
            </div>
          </div>
          
          <form class="form-horizontal" method="post" action="<%= action %>">
          
            <div class="form-group">
              <label for="given_name" class="col-sm-2 control-label">First Name</label>
              <div class="col-sm-4">
                <input type="text" class="form-control" id="given_name" name="given_name" placeholder="Mary" value=" ">
              </div>
            </div>
  
            <div class="form-group">
            <label for="family_name" class="col-sm-2 control-label">Last Name</label>
              <div class="col-sm-4">
                <input type="text" class="form-control" id="family_name" name="family_name" placeholder="Smith" value=" ">
              </div>
            </div>

            <div class="form-group">
            <label for="family_name" class="col-sm-2 control-label">Company</label>
              <div class="col-sm-4">
                <input type="text" class="form-control" id="company" name="company" placeholder="Stemcell" value=" ">
              </div>
            </div>
            
            <div class="form-group">
            <label for="policy" class="col-sm-2 control-label">I agree to the Privacy Policy</label>
              <div class="col-sm-4">
                <input type="checkbox" class="form-control" id="policy" name="policy" value=" ">
              </div>
            </div>
            
            <div class="form-group">
              <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-default">Submit</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </body>
    </html>
  `;
  
  return ejs.render(template, data);
}

function renderReturnView (data) {
  const template = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
    </head>
    <body>
      <form id="return_form" method="post" action="<%= action %>">
        <% Object.keys(formData).forEach((key) => { %>
        <input type="hidden" name="<%= key %>" value="<%= formData[key] %>">
        <% }); %>
      </form>
      <script>
        // automatically post the above form
        var form = document.getElementById('return_form');
        form.submit();
      </script>
    </body>
    </html>
  `;
  
  return ejs.render(template, data);  
}